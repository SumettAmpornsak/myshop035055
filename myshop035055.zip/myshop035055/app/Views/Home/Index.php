<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $title; ?></title>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>
<style>
    .warpper-card-img img {
        width: 100%;
        height: 200px;
        object-fit: cover;
    }

    .carousel-caption {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        background-color: rgba(0, 0, 0, 0.7);
        padding: 5px;
        border-radius: 1px;
        color: white;
    }

    .carousel-caption h1,
    .carousel-caption p,
    .carousel-caption a {
        color: white;
    }

    .carousel-caption a:hover {
        text-decoration: none;
    }

    .btn {
        border: none;
        border-radius: 5px;
        padding: 12px 20px;
        font-size: 16px;
        cursor: pointer;
        background-color: #282A35;
        color: white;
        position: relative;
    }

    .ribbon {
        width: 60px;
        font-size: 14px;
        padding: 4px;
        position: absolute;
        right: -25px;
        top: -12px;
        text-align: center;
        border-radius: 25px;
        transform: rotate(20deg);
        background-color: #ff9800;
        color: white;
    }

    .carousel-img {
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
    }

    .carousel-caption {
        top: 40%;
    }

    .backscreen {
        background: rgba(0, 0, 0, 0.5);
        height: 100%;
    }

    /* Add shadow to the product card */
    .card {
        top: 10%;   
        box-shadow: 0 4px 8px rgba(0, 0, 0, 1);
        transition: all 0.3s ease-in-out;
    }

    .card:hover {
        top: 5%;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }
    .container h1 span{
        border-bottom: 3px solid #00f7ff;
        padding-bottom: 0px;
    }
</style>


</head>
<br>

<body>
    <div class="container">
        <!-- Section Carousel -->
        <section id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner" data-bs-interval="1000">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/images/blog/Banner01.jpg" alt="First slide">
                    <div class="carousel-caption">
                        <h1 class="display-3 font-weight-bold">"ยินดีต้อนรับ"</h1>
                        <p class="lead">Game Online</p>
                        <a class="btn btn-primary" href="#" role="button">หน้าหลัก</a>
                    </div>
                    <div class="backscreen"></div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/blog/Banner02.jpg" alt="Second slide">
                    <div class="carousel-caption">
                        <h1 class="display-2 font-weight-bold">"สินค้า"</h1>
                        <p class="lead">สินค้าร้าน Game Online</p>
                        <a class="btn btn-primary" href="shop" role="button">เลือกดูสินค้า</a>
                    </div>
                    <div class="backscreen"></div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="assets/images/blog/Banner03.jpg" alt="Third slide">
                    <div class="carousel-caption">
                        <h1 class="display-2 font-weight-bold">"ติดต่อ"</h1>
                        <p class="lead">ช่องทางติดต่อ</p>
                        <a class="btn btn-primary" href="about/contact" role="button">ติดต่อ</a>
                    </div>
                    <div class="backscreen"></div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </a>
        </section>
        <!-- End Section Carousel -->
    </div>

    <br>
    <section class="container">
        <h1 class="border-short-bottom text-center"><span>สินค้าแนะนำ</span></h1>

        <div class="row d-flex justify-content-center">
            <section class="col-12 col-sm-6 col-md-4 p-2">
                <div class="card h-100">
                    <a href="#" class="warpper-card-img">
                        <img class="card-img-top" src="uploads/1718935950_9d09a3a0dc0f183486fc.jpg" alt="uploads/1718935950_9d09a3a0dc0f183486fc.jpg">
                    </a>

                    <div class="card-body">
                        <h5 class="card-title">GTA V (PC / DVD-ROM)</h5>
                        <p class="card-text">Shop for Grand Theft Auto V PC DVD-ROM experience the thrill and excitement
                            of this popular game. Get the best deals</p>
                    </div>
                    <div class="p-2">

                    </div>
                    <div class="p-2">
                        <a href="shop" class="btn">ดูสินค้าทั้งหมด <span class="ribbon">NEW</span></a>
                    </div>
                </div>
            </section>
            <section class="col-12 col-sm-6 col-md-4 p-2">
                <div class="card h-100">
                    <a href="#" class="warpper-card-img">
                        <img class="card-img-top" src="uploads/1718935999_fff4aedc9cbd2a923a4a.jpg" alt="uploads/1718935999_fff4aedc9cbd2a923a4a.jpg">
                    </a>
                    <div class="card-body">
                        <h5 class="card-title">MINECRAFT: STARTER COLLECTION</h5>
                        <p class="card-text">The infinite possibilities in Minecraft just got bigger! The gaming
                            phenomenon comes to the console with new features designed specifically.</p>
                    </div>
                    <div class="p-2">
                        <!-- <a href="room-detail.php?id=4" class="btn btn-primary btn-block">จองห้องประชุม</a> -->
                    </div>
                    <div class="p-2">
                        <a href="shop" class="btn">ดูสินค้าทั้งหมด <span class="ribbon">NEW</span></a>
                    </div>
                </div>
            </section>
            <section class="col-12 col-sm-6 col-md-4 p-2">
                <div class="card h-100">
                    <a href="#" class="warpper-card-img">
                        <img class="card-img-top" src="uploads/1718936057_670b874464a9f9f3bd47.jpg" alt="uploads/1718936057_670b874464a9f9f3bd47.jpg">
                    </a>
                    <div class="card-body">
                        <h5 class="card-title">Pokémon Advanced Complete Collection (DVD)</h5>
                        <p class="card-text">Amazon.com: Pokémon Advanced Complete Collection (DVD) : Various, Various:
                            Movies & TV.</p>
                    </div>
                    <div class="p-2">
                        <!-- <a href="room-detail.php?id=5" class="btn btn-primary btn-block">จองห้องประชุม</a> -->
                    </div>
                    <div class="p-2">
                        <a href="shop" class="btn">ดูสินค้าทั้งหมด <span class="ribbon">NEW</span></a>
                    </div>

                </div>
            </section>
        </div>
    </section>

    <!-- Section Footer -->

    <!-- Bootstrap JS, jQuery, and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <br><br><br><br><br>
</body>

</html>