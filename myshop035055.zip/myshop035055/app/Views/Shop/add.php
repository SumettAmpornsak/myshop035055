<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title>ตะกร้า</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="container mt-5">

    <h1>จำนวนสินค้าที่เลือก <span class="translate-middle badge rounded-pill bg-warning"><?= $itemCount > 99 ? '99+' : $itemCount; ?> </span> ชิ้น</h1>

    <?php if (session()->getFlashdata('message')) : ?>
        <div class="alert alert-info">
            <?= session()->getFlashdata('message'); ?>
        </div>
    <?php endif; ?>

    <table class="table table-bordered mb-4">
        <thead class="text-center">
            <tr>
                <th>ลำดับ</th>
                <th>รูปภาพ</th>
                <th>ชื่อสินค้า</th>
                <th>ราคา</th>
                <th>สถานะ</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($products)) : ?>
                <tr>
                    <td colspan="5" class="text-center">ยังไม่มีสินค้าที่เลือกในตะกร้า</td>
                </tr>
            <?php else : ?>
                <?php $totalPrice = 0; ?>
                <?php foreach ($products as $index => $product) : ?>
                    <tr class="text-center">
                        <td><?= $index + 1; ?></td>
                        <td>
                            <img src="<?= base_url($product['image']); ?>" alt="<?= esc($product['name']); ?>" style="width: 50px; height: auto;">
                        </td>
                        <td><?= esc($product['name']); ?></td>
                        <td><?= esc(number_format($product['price'], 2)); ?> บาท</td>
                        <td>
                            <form method="POST" action="<?= base_url('shop/remove/' . $index); ?>" style="display:inline;">
                                <button type="button" class="btn btn-danger" onclick="confirmRemove(<?= $index; ?>)">ลบ</button>
                            </form>
                        </td>
                    </tr>
                    <?php $totalPrice += $product['price']; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if (!empty($products)) : ?>
        <div class="text-right">
            <h4>ราคารวม <?= number_format($totalPrice, 2); ?> บาท</h4>
        </div>
    <?php endif; ?>

    <a class="btn btn-primary ml-2" href="<?= base_url(); ?>shop">เลือกสินค้าเพิ่ม</a>
    <button class="btn btn-success ml-2" onclick="handlePayment()">ชำระเงิน</button>

    <script>
    function handlePayment() {
        Swal.fire({
            title: 'กำลังดำเนินการชำระเงิน...',
            text: 'กรุณารอสักครู่',
            icon: 'info',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                fetch("<?= base_url('shop/checkout'); ?>", {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({
                        'csrf_test_name': '<?= csrf_hash(); ?>' // เพิ่ม CSRF token
                    })
                })
                .then(response => response.json())
                .then(data => {
                    Swal.close();
                    if (data.success) {
                        Swal.fire({
                            title: 'ชำระเงินสำเร็จ!',
                            text: 'คุณจะถูกนำกลับไปยังหน้าหลักของร้านค้า',
                            icon: 'success',
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'ตกลง'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = "<?= base_url('shop'); ?>";
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'ชำระเงินไม่สำเร็จ',
                            text: 'กรุณาเลือกสินค้าก่อน!',
                            icon: 'error',
                            confirmButtonColor: '#d33',
                            confirmButtonText: 'ตกลง'
                        });
                    }
                });
            }
        });
    }
</script>
</body>

</html>
