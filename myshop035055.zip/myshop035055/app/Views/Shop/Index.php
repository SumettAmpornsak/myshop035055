<style>
    .card {
        display: flex;
        flex-direction: column;
    }
    .card-img-top {
        object-fit: cover;
        height: 300px; /* Adjust this height as needed */
    }
    .card-body {
        flex: 1; /* This makes the body grow to fill the space */
        max-height: 250px; /* Limit the height of the card body */
        overflow: hidden; /* Hide overflowing text */
    }
    .card-body .card-text {
        display: -webkit-box;
        -webkit-line-clamp: 3; /* Number of lines to show */
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis; /* Add ellipsis (...) at the end */
    }
    .card-footer {
        text-align: center;
    }
</style>
<br>
<div class="container">
    <h1 class="mt-3">สินค้าทั้งหมด</h1>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-5 g-3">
        <?php foreach ($products as $product) : ?>
            <div class="col">
                <div class="card h-100">
                    <?php if ($product['image'] != '' && file_exists($product['image'])) : ?>
                        <img src="<?= $product['image']; ?>" class="card-img-top product-image" alt="รูปภาพ">
                    <?php endif ?>
                    <div class="card-body">
                        <h4 class="card-title"><?= $product['name']; ?></h4>
                        <p class="card-text"><?= $product['description']; ?></p>
                    </div>
                    <div class="card-footer">
                        <h5><?= number_to_currency($product['price'], 'THB', 'th-TH'); ?></h5>
                        <form method="POST" action="<?= base_url('shop/add/' . $product['product_id']); ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-shopping-cart"></i> เพิ่มในตระกร้า
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div>
</div>
<br>
<br>
<br>
<br>
<br>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const productImages = document.querySelectorAll('.product-image');
        const selectProductButtons = document.querySelectorAll('.select-product');

        productImages.forEach(image => {
            image.addEventListener('click', function() {
                const productName = this.closest('.card').querySelector('.card-title').innerText;

                Swal.fire({
                    title: 'เกม ' + productName,
                    imageUrl: this.src,
                    imageWidth: 500,
                    imageHeight: 500,
                    imageAlt: 'รูปภาพของ ' + productName
                });
            });
        });

        selectProductButtons.forEach(button => {
            button.addEventListener('click', function() {
                const productId = this.getAttribute('data-id');
                
                if (productId) {
                    // ส่งข้อมูลไปยังเซิร์ฟเวอร์เพื่อเลือกสินค้า
                    fetch('<?= base_url('shop/selectProduct') ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({ product_id: productId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: data.message,
                                text: 'สินค้า ID: ' + data.product_id
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'เกิดข้อผิดพลาด',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            icon: 'error',
                            title: 'เกิดข้อผิดพลาด',
                            text: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้'
                        });
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'เกิดข้อผิดพลาด',
                        text: 'ไม่พบข้อมูลสินค้า'
                    });
                }
            });
        });
    });
</script>
