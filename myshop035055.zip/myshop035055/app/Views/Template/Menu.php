<nav class="navbar navbar-expand-lg navbar-light bg-dark text-light">
    <div class="container-fluid">
        <a class="navbar-brand text-light fw-bold" href="<?= base_url(); ?>">Game Online</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menubar" aria-controls="menubar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon text-light">M</span>
        </button>
        <div class="collapse navbar-collapse" id="menubar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= ($activePage === 'home') ? 'active' : ''; ?>" aria-current="page" href="<?= base_url(); ?>home">หน้าหลัก</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($activePage === 'shop') ? 'active' : ''; ?>" href="<?= base_url(); ?>shop">สินค้า</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= ($activePage === 'about') ? 'active' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        เกี่ยวกับ
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item <?= ($activePage === 'shipping') ? 'active' : ''; ?>" href="<?= base_url(); ?>about/shipping">ข้อมูลจัดส่ง</a></li>
                        <li><a class="dropdown-item <?= ($activePage === 'contact') ? 'active' : ''; ?>" href="<?= base_url(); ?>about/contact">ข้อมูลติดต่อ</a></li>
                    </ul>
                </li>
                <?php if (session()->get('logged_in')) : ?>
                    <?php if (session()->get('role') === 'admin') : ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($activePage === 'user') ? 'active' : ''; ?>" href="<?= base_url(); ?>user">จัดการผู้ใช้</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($activePage === 'product') ? 'active' : ''; ?>" href="<?= base_url(); ?>product">จัดการสินค้า</a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-light" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?= $loggedUser['name']; ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item " href="<?= base_url(); ?>logout">ออกจากระบบ</a></li>
                        </ul>
                    </li>
                    <button type="button" class="btn btn-light position-relative ms-3" onclick="window.location.href='<?= base_url(); ?>shop/add'">
                        <i class="fas fa-shopping-cart text-primary"></i> ตระกร้าสินค้า
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?= isset($itemCount) && $itemCount > 99 ? sprintf('%d+', $itemCount) : (isset($itemCount) ? $itemCount : '0'); ?>
                            <span class="visually-hidden-focusable">สินค้าที่เลือกแล้ว</span>
                        </span>
                    </button>
                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($activePage === 'login') ? 'active' : ''; ?>" href="<?= base_url(); ?>login">เข้าสู่ระบบ</a>
                    </li>
                <?php endif ?>
            </ul>
        </div>
    </div>
</nav>

<style>
    .navbar-nav .nav-link {
        color: #ffffff; /* ตัวหนังสือสีขาว */
        transition: color 0.6s ease;
    }

    .navbar-nav .nav-link:hover {
        color: #ffcc00; /* เปลี่ยนเป็นสีทองเมื่อเลื่อนเมาส์ไป */
    }

    .navbar-nav .nav-link.active {
        font-weight: bold;
        color: #ffcc00 !important; /* เปลี่ยนสีของลิงค์ที่เลือก */
    }

    .btn-light {
        background-color: #ffffff;
        border: 6px solid #d3d3d3;
    }

    .btn-light:hover {
        background-color: #f8f9fa;
    }

    .dropdown-menu .dropdown-item {
        color: #000; /* ตัวหนังสือในเมนูดรอปดาวน์สีขาว */
    }

    .dropdown-menu .dropdown-item:hover {
        color: #ffcc00; /* เปลี่ยนเป็นสีทองเมื่อเลื่อนเมาส์ไป */
    }
</style>
