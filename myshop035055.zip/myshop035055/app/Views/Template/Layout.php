<!DOCTYPE html>
<html lang="en">

<head>
    <?= $template['head']; ?>
    <!-- Favicon -->
    <!-- <link rel="icon" href="https://www.expo-shop.ro/wp-content/uploads/2023/09/slide-supermarket_600x400.jpg" type="image/jpeg"> -->
    <link rel="icon" type="image/png" sizes="16x16" href="https://png.pngtree.com/png-vector/20190223/ourmid/pngtree-vector-house-icon-png-image_695726.jpg">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-dark ">
        <a class="navbar-brand" href="#">
            <img src="https://www.expo-shop.ro/wp-content/uploads/2023/09/slide-supermarket_600x400.jpg" alt="Logo" style="width:40px; margin-left: 10px; border-radius:10%;">
        </a>
        <?= $template['menu']; ?>
    </nav>
    <main>
        <?= $template['content']; ?>
    </main>
    <footer class="bg-dark fixed-bottom">
        <?= $template['footer']; ?>
    </footer>
</body>

</html>
