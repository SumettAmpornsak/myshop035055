<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('assets/images/BG01.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
        }

        .col {
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }

        .tb {
            font-weight: bold;
        }
        .profile p {
            margin: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <form class="row my-5" method="post" action="<?= base_url() ?>login/check">
            <div class="col col-12 col-md-10 col-lg-5 mx-auto border border-2 rounded-5 p-5">
                <div class="text-center" style="margin-top: 12px;">
                    <h3 class="mb-3 ">เข้าสู่ระบบ</h3>
                    <p class="text-muted mt-1 tb">“The best solution for your fun”</p>
                </div>
                <div class="mb-3">
                    <label for="username" class="form-label">ชื่อผู้ใช้</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Username">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">รหัสผ่าน</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                </div>
                <div class="mt-2 text-end">
                    <button type="button" class="btn btn-link" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">ลืมรหัสผ่าน</button>
                </div>
                <div class="d-grid">
                    <button class="btn btn-primary" type="submit">เข้าสู่ระบบ</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1" aria-labelledby="forgotPasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="forgotPasswordModalLabel">Help</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    กรุณาติดต่อแอดมินเพื่อขอรีเซ็ตรหัสผ่านของคุณ
                    <div class="profile">
                        <p>นาย สุเมธ อำพรศักดิ์ (ปลาย)<br>
                            ผู้ดูแลระบบ<br>
                            <a href="mailto:644230035@webmail.npru.ac.th">644230035@webmail.npru.ac.th</a>
                        </p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
