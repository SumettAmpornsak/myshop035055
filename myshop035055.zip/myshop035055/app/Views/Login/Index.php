<div class="container">
    <form class="row my-5" method="post" action="<?= base_url() ?>login/check">
        <div class="col col-12 col-md-10 col-lg-5 mx-auto border border-2 border-primary rounded-3 p-4">
            <div class="text-center" style="margin-top: 12px;">
                <h3 class="mb-3 ">เข้าสู่ระบบ</h3>
                <p class="text-muted mt-1">“The best solution for your fun”</p>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">ชื่อผู้ใช้</label>
                <input type="text" class="form-control" name="username" id="username" placeholder="Username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">รหัสผ่าน</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Password">
            </div>
            <div class="d-grid">
                <button class="btn btn-primary" type="submit">เข้าสู่ระบบ</button>
            </div>
        </div>
    </form>
</div>