
    <style>
        #about {
            padding-top: 100px; /* ปรับระยะห่างจากด้านบน */
            padding-bottom: 60px;
            text-align: center;
        }

        #about h2 {
            color: #000000;
            margin-bottom: 12px;
        }

        #about h2 span {
            border-bottom: 3px solid #00f7ff;
            padding-bottom: 0px;
        }

        #about .profile {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 600px;
            margin: 0 auto;
        }

        #about .profile img {
            margin-top: 50px;
            border-radius: 50%;
            width: 100px; /* ปรับขนาดของรูปภาพตามที่ต้องการ */
            height: 100px;
        }

        #about .profile p {
            margin: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- ส่วนเนื้อหา 1 เกี่ยวกับฉัน -->
        <section id="about">
            <div>
                <h2><span>ข้อมูลติดต่อ</span></h2>
                <div class="profile">
                    <div class="profile-left">
                        <img src="https://scontent.fbkk12-1.fna.fbcdn.net/v/t39.30808-6/329349836_575940637728421_5009252494272015894_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=833d8c&_nc_ohc=aJ5DIKU57nwQ7kNvgHMAIbG&_nc_ht=scontent.fbkk12-1.fna&oh=00_AYDOShxZZOeKbe50n0laOwrQi9GENsDjeYTXRz9u8An7CA&oe=66A59430" alt="สุเมธ">
                        <p>นาย สุเมธ อำพรศักดิ์ (ปลาย)<br>
                            ผู้ดูแลระบบ<br>
                            <a href="mailto:644230035@webmail.npru.ac.th">644230035@webmail.npru.ac.th</a>
                        </p>
                    </div>
                    <div class="profile-right">
                        <img src="https://scontent.fbkk8-2.fna.fbcdn.net/v/t39.30808-6/431031241_3174760476152397_3800015882088201122_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=a5f93a&_nc_ohc=ymuZnp8Xu2MQ7kNvgFjfsa4&_nc_ht=scontent.fbkk8-2.fna&oh=00_AYDRSdmTOwAbpJxhkG2aECJDaDA0JiewV1zpVZ4RPDTP5w&oe=66A5AAE0" alt="วิชัย">
                        <p>นาย วิชัย ทองเปราะ (อาร์ท)<br>
                            ผู้ดูแลระบบ<br>
                            <a href="mailto:644230055@webmail.npru.ac.th">644230055@webmail.npru.ac.th</a>
                        </p>
                    </div>
                </div>
            </div>
        </section> <!-- About Section End 1 -->
    </div>
</body>
</html>
