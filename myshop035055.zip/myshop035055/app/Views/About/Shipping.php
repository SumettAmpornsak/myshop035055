<style>
    #about {
        padding-top: 30px;
        padding-bottom: 60px;
        text-align: center;
        overflow: hidden;
    }

    #about h2 {

        color: #000000;
        margin-bottom: 12px;
    }

    #about h2 span {
        border-bottom: 3px solid #00f7ff;
        padding-bottom: 0px;
    }

    #about p {
        line-height: 30px;
        color: #000000;
    }

</style>

<div class="container">
    <!-- ส่วนเนื้อหา 1 เกี่ยวกับฉัน -->
    <section id="about">
        <div>
            <div class="nine columns main-col">

                <h2><span>ข้อมูลจัดส่ง</span></h2><br>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2739.344930752118!2d100.02674759742608!3d13.837912431159229!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e2e451d74429ad%3A0xf01923824353060!2sNakhon%20Pathom%20Rajabhat%20University!5e0!3m2!1sen!2sth!4v1720433317186!5m2!1sen!2sth" width="600" height="450" style="border:30px; color: #00f7ff; " allowfullscreen="yes" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    <br>
                <p>ผู้จัดส่ง<br>
                </p>
                <p>นาย วิชัย ทองเปราะ (อาร์ท)<br>
                    
                    <a href="mailto:">644230055@webmail.npru.ac.th</a>

                </p>
            </div> <!-- end .main-col -->
        </div>
    </section> <!-- About Section End 1 -->
</div>