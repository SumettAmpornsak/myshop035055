<?php

namespace App\Controllers;

use App\Models\UserModel;

class Template extends BaseController
{
    /**
     * Renders a view with the common template layout.
     *
     * @param string $view The view to be rendered.
     * @param array $data The data to be passed to the view.
     * @param string $activePage The page that should be highlighted as active.
     * @return string The rendered view.
     */
    public function Render($view, $data = [], $activePage = ''): string
    {
        // Check if user is logged in and retrieve user details if true
        if (session()->get('logged_in'))
        {
            $rowUser = (new UserModel())->find(session()->get('user_id'));
            $data['loggedUser'] = $rowUser;
        }
        
        // Add the active page to data
        $data['activePage'] = $activePage;
        
        // Prepare the template data
        $data['template'] = array(
            'head' => view('Template/Head', $data),
            'menu' => view('Template/Menu', $data),
            'footer' => view('Template/Footer', $data),
            'content' => view($view, $data)
        );
        
        // Render the layout with the template data
        return view('Template/Layout', $data);
    }
}
