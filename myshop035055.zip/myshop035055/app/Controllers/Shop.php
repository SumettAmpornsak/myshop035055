<?php
namespace App\Controllers;

use App\Models\ProductModel;
use App\Controllers\Template;

class Shop extends BaseController
{
    public function index()
    {
        $productModel = new ProductModel();
        $products = $productModel->findAll();

        helper('number');
        $template = new Template();
        return $template->Render('Shop/Index', [
            'title' => 'สินค้า',
            'products' => $products,
            'itemCount' => $this->getCartItemCount()
        ]);
    }

    public function addProduct($id)
    {
        $productModel = new ProductModel();
        $product = $productModel->find($id);

        if (!$product) {
            return "ไม่พบสินค้า!";
        }

        $session = session();
        $cart = $session->get('cart') ?? [];
        $cart[] = $product;
        $session->set('cart', $cart);
        $session->setFlashdata('message', 'เพิ่มสินค้าเรียบร้อย!');

        return redirect()->to('/shop/add');
    }

    public function showCart()
    {
        $session = session();
        $cart = $session->get('cart') ?? [];
        $itemCount = count($cart);

        helper('number');
        return view('shop/add', [
            'products' => $cart,
            'itemCount' => $itemCount
        ]);
    }

    public function removeProduct($index)
    {
        $session = session();
        $cart = $session->get('cart') ?? [];

        if (isset($cart[$index])) {
            unset($cart[$index]);
            $session->set('cart', array_values($cart));
            $session->setFlashdata('message', 'สินค้าถูกลบเรียบร้อย!');
        }

        return redirect()->to('/shop/add');
    }

    public function clearCart()
    {
        $session = session();
        $session->remove('cart');
        $session->setFlashdata('message', 'Cart cleared!');
        return redirect()->to('/shop/add');
    }

    public function checkout()
    {
        $session = session();
        $cart = $session->get('cart') ?? [];
        $itemCount = count($cart);

        if ($itemCount > 0) {
            $session->remove('cart'); // เคลียร์ตะกร้าสินค้า
            $session->setFlashdata('message', 'ชำระเงินสำเร็จ!');
            return $this->response->setJSON(['success' => true]);
        } else {
            $session->setFlashdata('message', 'กรุณาเลือกสินค้าก่อน!');
            return $this->response->setJSON(['success' => false]);
        }
    }

    private function getCartItemCount()
    {
        $session = session();
        $cart = $session->get('cart') ?? [];
        return count($cart);
    }
}
