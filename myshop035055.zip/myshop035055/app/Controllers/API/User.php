<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;

class User extends ResourceController
{
    protected $modelName = 'App\Models\UserModel';
    protected $format = 'json';

    public function Index()
    {
        return $this->respond($this->model->findAll());
    }

    public function Show($id = null)
    {
        return $this->respond($this->model->find($id));
    }
    public function Create()
    {
        $data = $this->request->getPost();

        $validation = service('validation');
        $validation->setRules(array(
            'username' => 'required|min_length[5]',
            'password' => 'required|min_length[5]',
            'name' => 'required|min_length[5]',
            'email' => 'required|valid_email',
        ));
        // Run validation
        if (!$validation->withRequest($this->request)->run()) {
            return $this->fail($validation->getErrors());
        }

        // Add default role if not provided
        $data['role'] = 'user';

        // Insert data into model
        if ($this->model->insert($data)) {
            return $this->respondCreated(array('message' => 'User created successfully.'));
        }
        return $this->failServerError('Failed to create user.');
    }
}